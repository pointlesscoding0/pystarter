from setuptools import setup, find_packages

setup(
    name='pystarter',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'openai',
        'dotenv'
        'pyinstaller'
    ],
    entry_points={
        'console_scripts': [
            'pystarter=pystarter.cli:main'
        ]
    },
    author='Neonskull(pointlesscoding)',
    author_email='your.email@example.com',
    description='A Python package to do XYZ',
    url='https://github.com/pointlesscoding0/pystarter',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent'
    ],
)